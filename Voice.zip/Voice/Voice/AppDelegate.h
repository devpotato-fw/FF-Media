//
//  AppDelegate.h
//  Voice
//
//  Created by wangfang on 2016/10/12.
//  Copyright © 2016年 onefboy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

